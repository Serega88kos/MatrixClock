#if defined(ESP8266) || defined(ESP32)

#include "GyverNTP.h"

GyverNTP NTP;

#endif