#pragma once
#include <Arduino.h>

namespace ghc {
class HubCore;
}