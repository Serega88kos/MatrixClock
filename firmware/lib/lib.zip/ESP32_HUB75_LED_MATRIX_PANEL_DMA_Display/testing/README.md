Sample app to simulate the VirtualMatrixPanel class for testing / optimisation, without having to test with physical panels.

```
g++ -o myapp.exe virtual.cpp
```